<?php

namespace App\Controllers;

use App\Models\MahasiswaModel;

class mahasiswa extends BaseController
{
    public function index()
    {
        $this->mhs1 = new MahasiswaModel();
        $this->mhs2 = new MahasiswaModel();
        $this->mhs3 = new MahasiswaModel();

        // memberikan nilai kepada object
        $this->mhs1->id = 1;
        $this->mhs1->nama = "Rizwan Nur Saputra";
        $this->mhs1->nim = "0110221312";
        $this->mhs1->gender = "L";
        $this->mhs1->tmp_lahir = "Bogor";
        $this->mhs1->tgl_lahir = "22 September 2002";
        $this->mhs1->ipk = 3.86;
        
        $this->mhs2->id = 2;
        $this->mhs2->nama = "Andi Galih";
        $this->mhs2->nim = "0110221313";
        $this->mhs2->gender = "L";
        $this->mhs2->tmp_lahir = "Tanggerang";
        $this->mhs2->tgl_lahir = "22 Oktober 2002";
        $this->mhs2->ipk = 3.66;

        $this->mhs3->id = 3;
        $this->mhs3->nama = "Ihsanullah";
        $this->mhs3->nim = "0110221314";
        $this->mhs3->gender = "L";
        $this->mhs3->tmp_lahir = "Parung Panjang";
        $this->mhs3->tgl_lahir = "08 Juni 2002";
        $this->mhs3->ipk = 3.56;


        $list_mhs = [$this->mhs1, $this->mhs2 ,$this->mhs3];
        $data['lis_mhs'] = $list_mhs;
        
        // return sebuah view dan mengirimkan sebuah data array
        return view('mahasiswa/index', $data);
    }
}